					Installation  process

Step 1  Edit the dbconfig.php file according to your MySQL Creditionals but don't change db name.

Step 2  visit : yourdomain.com/feedback/install.php

Database automatically install on your MySQL system 

Step 3  Delete the install.php file for security

Hurray Now you are up and running

Step 4 Go to yourdomain.com/feedback to check if everything works properly.


If you have any problem Contact me
GitHub : github.com/devesh7272
				github.com/drlabpro

Email : connect.world12345@gmail.com

Thanks for choosing my work 